# Calculator with basic arithmetic functions.

def add(a, b): return a + b
def subtract(a, b): return a - b
def multiply(a, b): return a * b
def divide(a, b): return a / b if b != 0 else 'Error: Division by zero'
def trunc_div(a, b): return a // b if b != 0 else 'Error: Division by zero'
def modulus(a, b): return a % b
def exponent(a, b): return a ** b
def main():
    print("Welcome to my calculator!")
    print("Please enter one of the following options: +, -, *, /, //, % or **")
    while True:
        option = input("Enter an option: ")
        if option in {"+", "-", "*", "/", "//", "%", "**"}:
            break
        print("Invalid option. Please try again.")
    print("Please enter two numbers:")
    num1 = float(input("Enter the first number: "))
    num2 = float(input("Enter the second number: "))
    if option == "+":
        print(add(num1, num2))
    elif option == "-":
        print(subtract(num1, num2))
    elif option == "*":
        print(multiply(num1, num2))
    elif option == "/":
        print(divide(num1, num2))
    elif option == "//":
        print(trunc_div(num1, num2))
    elif option == "%":
        print(modulus(num1, num2))
    elif option == "**":
        print(exponent(num1, num2))
    else:
        print("Error: Invalid option")
    print("Thank you for using my calculator!")
    input("Press enter to exit ...")

if __name__ == "__main__":
    main()
