'''This python program creates a function to calculate the number of upper case and lower case letters in the string provided by the user'''

def count_case_letters(input_string):
    upper_count = 0
    lower_count = 0
    
    for char in input_string:
        # Check if the character is an uppercase letter
        if char.isupper():
            upper_count += 1
        # Check if the character is a lowercase letter
        elif char.islower():
            lower_count += 1
    
    print("Number of uppercase letters:", upper_count)
    print("Number of lowercase letters:", lower_count)

user_string = input("Enter a string: ")
count_case_letters(user_string)
