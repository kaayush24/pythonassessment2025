'''This python program creates a function to check whether the given number is Armstrong or not.'''

def is_armstrong(number):
    
    digits = str(number)
    no_of_digits = len(digits)
    total_sum = 0
    
    for digit in digits:
        total_sum += int(digit) ** no_of_digits
    
    if number == total_sum:
        print (f"The given number {digits} is an armstrong number.")
        
    else:
        print (f"The given number {digits} is not an armstrong number.")

user_input = int(input("Enter a number: "))
is_armstrong(user_input)    
        