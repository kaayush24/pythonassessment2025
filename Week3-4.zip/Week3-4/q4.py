'''This python program creates a function to accept a list of names and return the sorted order of names back.'''

def sorted_list(names):
    
    names.sort()
    return names

i = 1
name_list = []
no_of_names = int(input("Enter the no. of names you want to list: "))

while i < (no_of_names + 1):
     name = input(f"Enter name no {i}: ")
     name_list.append(name)
     i += 1
     
new_name_list = sorted_list(name_list)
print (new_name_list)
