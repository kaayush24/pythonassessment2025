'''This python program creates a function to check whether the given number is prime or not'''

def number_type(number):
    if number <= 1:
        print ("The number is not prime number.")
        return
    
    for i in range(2, number):
        if number % i == 0:
            print ("The number is not prime number.")
            break
        
    print("The number is prime number")
            
user_input = int(input("Enter a number: "))
number_type(user_input)