'''This python program ask user for two numbers and return the value of first number divided by second with two decimal place'''

#ask user to input two numbers
first_num = float(input("Enter the first number: "))
second_num = float(input("Enter the second number: "))

divided_value = first_num / second_num
rounded_value = round(divided_value, 2)
print (f"The value obtained from dividing first number by second number, with exactly two decimal place is {rounded_value}")