'''This python program import pi value and rounds it to five decimal places'''

from math import pi #imports the value of pi from math module

rounded_pi = round (pi, 5) #rounds pi to five decimal place
print (rounded_pi)
