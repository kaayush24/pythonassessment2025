'''This python program is a number guessing game. It generates a random number between 1 and 50. The user has 5 attempts to guess the correct
   number with each incorrect guess having feedback of too high or too low.'''

import random

# Generate a random number between 1 and 50
answer = random.randint(1, 50)

# Maximum number of attempts
max_attempts = 5

print("Welcome to the Number Guessing Game!")
print("You have 5 attempts to guess the correct number between 1 and 10.")


for attempt in range(1, max_attempts + 1):
    user_guess = int(input(f"Attempt {attempt}: Enter your guess: "))
    
    # Check the user's guess and provide feedback
    if user_guess < answer:
        print("Too low!")
    elif user_guess > answer:
        print("Too high!")
    else:
        print("Correct number! You win!")
        break  
else:
    print("Game Over! The correct number was:", answer)
