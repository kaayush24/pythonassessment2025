length = 9
width = 6
perimeter = 2*(length + width)
print (perimeter)