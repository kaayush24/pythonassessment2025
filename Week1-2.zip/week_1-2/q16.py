'''This Python program finds those numbers which are divisible by 7 and multiple of 5, between 1500 and 2000 (both included). '''

#list of numbers from 1500 to 2000
numbers = list(range(1500, 2001))

#an empty list to store the numbers
result = []

for num in numbers:
    #checking if the number is divisible by 7 and is also a multiple of 5
    if num % 7 == 0 and num % 5 == 0:
        result.append(num)

print("Numbers divisible by 7 and multiple of 5 between 1500 and 2000:", result)
