'''This python program finds the simple interest when the value of principle, rate of interest and time period is provided by the user.'''

#function to calculate simple interest
def simple_interest(p, t, r):
    simple_interest_value = p * t * r / 100
    return simple_interest_value

#inputs from the user
principle = float(input("Enter Principle: "))
time = float(input("Enter Time Period: "))
rate = float(input("Enter Rate of Interest: "))

simple_interest_value = simple_interest (principle, time, rate)
print (f"The simple interest when the value of principle, rate of interest and time period is provided by the user is {simple_interest_value}")
