'''This python program determines the euclidean distance between two coordinates which are entered by the user.'''

#function to calculate euclidean distance
def euclidean_distance(x1, y1, x2, y2):
    distance = ((x2 - x1)**2 + (y2 - y1)**2)**0.5 
    return distance

#user input
x1 = float(input("Enter the x-coordinate of the first point: "))
y1 = float(input("Enter the y-coordinate of the first point: "))
x2 = float(input("Enter the x-coordinate of the second point: "))
y2 = float(input("Enter the y-coordinate of the second point: "))

#call the function and also round the result value for clear understanding
distance = euclidean_distance(x1, y1, x2, y2)
rounded_distance = round (distance, 5)
print (f"The euclidean distance between the coordinates {x1, y1} and {x2, y2} is {rounded_distance}.")