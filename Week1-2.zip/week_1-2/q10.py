'''This python program find the unicode of your name'''

name = input("Enter your name: ")
unicode_values = []

#this loop give unicode value of each letter in your name including the spaces and adds to the unicode_value list
for char in name:
    unicode_values.append(ord(char))
    
print (f"The unicode valued of the entered name is, \n{unicode_values}")