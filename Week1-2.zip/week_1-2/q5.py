forename = input ("Enter your forename: ")
result = (forename + " ") * 5
print (result)