'''This python program gives 7.2 as int.'''

int_value = int(7.2) #this is a type conversion
print (f"Integer value of 7.2 is {int_value}.")