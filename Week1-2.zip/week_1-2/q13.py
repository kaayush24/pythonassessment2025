'''This python program convert the celsius value to fahrenheit'''

#function to convert celsius to fahrenheit
def celsius_to_fahrenheit(celsius):
    fahrenheit = (celsius * 9/5) + 32
    return fahrenheit

celsius_value = float(input("Enter celsius value: "))
fahrenheit = celsius_to_fahrenheit(celsius_value) #stores value in fahrenheit for future use.
print (f"{celsius_value} celsius converted to fahrenheit is {fahrenheit} fahrenheit.")