power = 2 ** 10
print (f"The value of 2 to the power 10 is {power}")