'''This python program takes input a number as input from user and determines wheather its even or odd'''

#function to determine odd or even
def even_or_odd(n):
    if n % 2 == 0:
        print ("The given number is even.")
    else:
        print ("The given number is odd.")
        

num = input("Enter an integer number: ")
even_or_odd(int(num)) #type conversion of string into int.