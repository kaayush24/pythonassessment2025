'''This program calculates the number of digits and letters in an input string'''

# Input a string from the user
input_string = input("Enter a string: ")

#counters for digits and letters
digit_count = 0
letter_count = 0

for char in input_string:
    # Check if the character is a digit
    if char.isdigit():
        digit_count = digit_count + 1
    # Check if the character is a letter
    elif char.isalpha():
        letter_count = letter_count + 1


print("Number of digits:", digit_count)
print("Number of letters:", letter_count)