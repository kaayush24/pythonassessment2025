'''This python program find the value of 200 modulus 12'''

value = 200 % 12 #this gives the value of 200 modulus 12
print (f"The value of 200 modulus 12 is {value}.")