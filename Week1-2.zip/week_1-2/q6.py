'''This python program left justifies name to fifteen spaces'''

forename = input("Enter your forename: ")

result = forename.ljust(15)
print("Your name left justified to 15 spaces:", "'" + result + "'")
