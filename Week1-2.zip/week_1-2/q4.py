def factorial(n):
    if n == 0 or n == 1:
        return 1
    else:
        return n * factorial (n-1)
    
first_num = 7
second_num = 5
num_value = factorial(first_num) - factorial(second_num)
print (f"The value of seven factorial minus five fatorial is {num_value}")